﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class ViewStudentsScores : System.Web.UI.Page
    {
        int tid;
        protected void Page_Load(object sender, EventArgs e)
        {
            tid = int.Parse(Session["teacher"].ToString());
            List<Student> student = DBConnectivty.TLoadAllScores(tid);
            foreach (var s in student)
            {
                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                cell1.Text = s.Fname;
                TableCell cell2 = new TableCell();
                cell2.Text = s.Game;
                TableCell cell3 = new TableCell();
                cell3.Text = s.Score.ToString();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                Table1.Rows.Add(row);
            }
        }
    }
}