﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CourseWorkTwo
{
    public class Person
    {
        int id;
        string fname;
        string lname;
        string email;
        string pass;

        public int Id
        {
            get
            {return id;}

            set
            {id = value;}
        }

        public string Fname
        {
            get
            {return fname; }

            set
            {fname = value;}
        }

        public string Lname
        {
            get
            {return lname;}

            set
            {lname = value;}
        }

        public string Email
        {
            get
            {return email; }

            set
            {email = value; }
        }

        public string Pass
        {
            get
            { return pass; }

            set
            { pass = value;}
        }
        public Person(int id,string fname,string lname,string email,string pass)
        {
            this.id = id;
            this.fname = fname;
            this.lname = lname;
            this.email = email;
            this.pass = pass;
        }
        public Person(int id, string fname, string lname, string email)
        {
            this.id = id;
            this.fname = fname;
            this.lname = lname;
            this.email = email;
        }
        public Person(int id,string fname)
        {
            this.id = id;
            this.fname = fname;
        }
        public Person(int id, string email,string pass)
        {
            this.id = id;
            this.email = email;
            this.pass = pass;
        }
    }
}