﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CourseWorkTwo.Startup))]
namespace CourseWorkTwo
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
