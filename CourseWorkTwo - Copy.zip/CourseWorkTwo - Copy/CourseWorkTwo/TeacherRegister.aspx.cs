﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class TeacherRegister : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Register_Click(object sender, EventArgs e)
        {
            string password = Password.Text;
            string confirm = Password2.Text;
            string fname = Fname.Text;
            string lname = Lname.Text;
            string email = Email.Text;
            if(fname == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your first name";
            }
            else if(lname == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your last name";
            }
            else if(email == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your email";
            }
            else if(password == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your password";
            }
            else if(confirm == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your password again";
            }
            else
            {
                if (password == confirm)
                {
                    //thread to store teacher to the database
                    Thread regteacher = new Thread(() => DBConnectivty.AddTeacher(fname, lname, email, password));
                    regteacher.Start();
                    Label1.Visible = true;
                    Label1.ForeColor = Color.FromArgb(51, 204, 51);
                    Label1.Text = "Registration is successful";
                    Fname.Text = "";
                    Lname.Text = "";
                    Email.Text = "";
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Password's donot Match";
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}