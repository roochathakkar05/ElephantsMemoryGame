﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class StudentRegister : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CBTeacher.DataSource = DBConnectivty.LoadTeacher();
                CBTeacher.DataTextField = "fname";
                CBTeacher.DataValueField = "id";
                CBTeacher.DataBind();
            }
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            string password = Password.Text;
            string confirm = Password2.Text;
            string fname = Fname.Text;
            string lname = Lname.Text;
            string email = Email.Text;
            string teacherid = CBTeacher.SelectedValue;
            if (fname == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your first name";
            }
            else if (lname == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your last name";
            }
            else if (email == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your email";
            }
            else if (password == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your password";
            }
            else if (confirm == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your password again";
            }
            else
            {
                if (password == confirm)
                {
                    //thread to store student to the database
                    Thread regstd = new Thread(() => DBConnectivty.AddStudent(fname, lname, email, password, teacherid));
                    regstd.Start();
                    Label1.Visible = true;
                    Label1.ForeColor = Color.FromArgb(51, 204, 51);
                    Label1.Text = "Registration is successful";
                    Fname.Text = "";
                    Lname.Text = "";
                    Email.Text = "";
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Password's donot Match";
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}