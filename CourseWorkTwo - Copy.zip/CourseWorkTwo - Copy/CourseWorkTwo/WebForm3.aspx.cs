﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        int gameid = 3;
        int stdid;
        int timetostart = 5;
        int mins = 05;
        int seconds = 05;
        int score = 0; // store the score
        Random Location = new Random();//Random location for images for shuffling
        List<ImageButton> images = new List<ImageButton>(); // store all the image button on the page
        char[] delimiterChars = { '~', '/', '.', ' ' };
        List<string> urll = new List<string>(); // store all the image url from the db
        List<string> urll2 = new List<string>(); // store all the image url from the db
        ImageButton guess1 = null; // store image button clicked
        ImageButton guess2 = null; // store image button clicked
        string s1 = ""; // store url retrieved from the database
        string s2 = ""; // store url retrieved from the database
        int id = 1; // used for retrival and resetting of url in the database
        int idd = 2; // used for retrival and resetting of url in the database
        string rand = "random"; // used for resetting of url
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Add Images to the list 
            images.Add(Card1);
            images.Add(Dup1);
            images.Add(Card2);
            images.Add(Dup2);
            images.Add(Card3);
            images.Add(Dup3);
            images.Add(Card4);
            images.Add(Dup4);
            images.Add(Card5);
            images.Add(Dup5);
            images.Add(Card6);
            images.Add(Dup6);
            images.Add(Card7);
            images.Add(Dup7);
            images.Add(Card8);
            images.Add(Dup8);
            images.Add(Card9);
            images.Add(Dup9);
            images.Add(Card10);
            images.Add(Dup10);
            images.Add(Card11);
            images.Add(Dup11);
            images.Add(Card12);
            images.Add(Dup12);
            #endregion
            if (!IsPostBack)
            {
                Session["timer1"] = timetostart;
                Session["timer2"] = mins;
                Session["timer3"] = seconds;
                Session["counter"] = 5;
                urll = DBConnectivty.Images(gameid);
                int n = urll.Count;
                while (n > 1)
                {
                    n--;
                    int k = Location.Next(n + 1);
                    string value = urll[k];
                    urll[k] = urll[n];
                    urll[n] = value;
                }
                Session["test"] = urll;

                for (int i = 0; i < images.Count; i++)
                {
                    images.ElementAt(i).ImageUrl = urll.ElementAt(i);
                }
            }
            stdid = int.Parse(Session["student"].ToString());
            List<String> dburl = new List<String>();
            dburl = DBConnectivty.LoadUrl1(id);
            foreach (var db in dburl)
            {
                s1 = db;
            }
            List<String> dburl2 = new List<String>();
            dburl2 = DBConnectivty.LoadUrl1(idd);
            foreach (var db2 in dburl2)
            {
                s2 = db2;
            }
        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            UpdatePanel2.Update();
        }
        protected void Card1_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card1.ImageUrl = list.ElementAt(0);
            string[] words = Card1.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card1.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card1.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }

            CheckImage();
        }
        protected void Dup1_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup1.ImageUrl = list.ElementAt(1);
            string[] words = Dup1.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup1.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup1.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }

            CheckImage();
        }
        protected void Card2_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card2.ImageUrl = list.ElementAt(2);
            string[] words = Card2.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card2.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card2.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }

            CheckImage();
        }
        protected void Dup2_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup2.ImageUrl = list.ElementAt(3);
            string[] words = Dup2.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup2.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup2.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }

            CheckImage();
        }
        protected void Card3_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card3.ImageUrl = list.ElementAt(4);
            string[] words = Card3.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card3.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card3.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup3_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup3.ImageUrl = list.ElementAt(5);
            string[] words = Dup3.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup3.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup3.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card4_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card4.ImageUrl = list.ElementAt(6);
            string[] words = Card4.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card4.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card4.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup4_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup4.ImageUrl = list.ElementAt(7);
            string[] words = Dup4.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup4.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup4.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card5_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card5.ImageUrl = list.ElementAt(8);
            string[] words = Card5.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card5.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card5.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup5_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup5.ImageUrl = list.ElementAt(9);
            string[] words = Dup5.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup5.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup5.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card6_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card6.ImageUrl = list.ElementAt(10);
            string[] words = Card6.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card6.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card6.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup6_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup6.ImageUrl = list.ElementAt(11);
            string[] words = Dup6.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup6.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup6.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card7_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card7.ImageUrl = list.ElementAt(12);
            string[] words = Card7.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card7.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card7.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup7_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup7.ImageUrl = list.ElementAt(13);
            string[] words = Dup7.ImageUrl.Split(delimiterChars);
            string url = (words[3]); ;
            if (s1 == "random")
            {
                Session["guess1"] = Dup7.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup7.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card8_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card8.ImageUrl = list.ElementAt(14);
            string[] words = Card8.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card8.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card8.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup8_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup8.ImageUrl = list.ElementAt(15);
            string[] words = Dup8.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup8.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup8.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card9_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card9.ImageUrl = list.ElementAt(16);
            string[] words = Card9.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card9.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card9.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup9_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup9.ImageUrl = list.ElementAt(17);
            string[] words = Dup9.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup9.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup9.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card10_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card10.ImageUrl = list.ElementAt(18);
            string[] words = Card10.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card10.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card10.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup10_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup10.ImageUrl = list.ElementAt(19);
            string[] words = Dup10.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup10.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup10.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card11_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card11.ImageUrl = list.ElementAt(20);
            string[] words = Card11.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card11.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card11.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup11_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup11.ImageUrl = list.ElementAt(21);
            string[] words = Dup11.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup11.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup11.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Card12_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Card12.ImageUrl = list.ElementAt(22);
            string[] words = Card12.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Card12.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Card12.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Dup12_Click(object sender, ImageClickEventArgs e)
        {
            var list = (List<string>)Session["test"];
            Dup12.ImageUrl = list.ElementAt(23);
            string[] words = Dup12.ImageUrl.Split(delimiterChars);
            string url = (words[3]);
            if (s1 == "random")
            {
                Session["guess1"] = Dup12.ID;
                DBConnectivty.addurl(url, id);
            }
            else if (s2 == "random")
            {
                Session["guess2"] = Dup12.ID;
                DBConnectivty.addurl(url, idd);
            }
            else
            {
                //Label5.Text = "this";
            }
            CheckImage();
        }
        protected void Timer2_Tick(object sender, EventArgs e)
        {
            foreach (var imgbtn in images)
            {
                imgbtn.ImageUrl = "~/Pictures/cover1.png";
            }
            Timer1.Enabled = false;
            Timer2.Enabled = false;
            Timer3.Enabled = true;
            Timer5.Enabled = true;
            Label1.Visible = true;
            Label2.Visible = true;
            Label9.Visible = true;
            Label8.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            Label6.Visible = false;
            Label7.Visible = false;
        }
        //---------------Function To check for matching Images------------------//
        public void CheckImage()
        {
            if (s2 != "random" && s1 != "random") // Check whether the string retrived from the Db are random or not
            {
                guess1 = Panel1.FindControl(Session["guess1"].ToString()) as ImageButton;
                guess2 = Panel1.FindControl(Session["guess2"].ToString()) as ImageButton;
                // Check if the URL retrieved from the Db are the same or not
                if (s1 == s2)
                {
                    DBConnectivty.addurl(rand, id);
                    DBConnectivty.addurl(rand, idd);
                    s1 = "";
                    s2 = "";
                    guess1.Visible = false;
                    guess2.Visible = false;
                    score = int.Parse(Label4.Text);
                    score = score + 10;
                    Label4.Text = score.ToString();
                    Session["guess1"] = null;
                    Session["guess2"] = null;
                    foreach (var imgbtn in images)
                    {
                        imgbtn.ImageUrl = "~/Pictures/cover1.png";
                    }
                    int newscore = int.Parse(Label4.Text);
                    if (newscore == 120)
                    {
                        Session["score"] = Label4.Text;
                        Label5.Text = Session["score"].ToString();
                        int finalscore = int.Parse(Label4.Text);
                        Thread storescore = new Thread(() => DBConnectivty.AddScore(finalscore, stdid, gameid));
                        storescore.Start();
                        Response.Redirect("GameOver.aspx");
                        Timer3.Enabled = false;
                    }
                }
                else
                {
                    DBConnectivty.addurl(rand, id);
                    DBConnectivty.addurl(rand, idd);
                    s1 = "";
                    s2 = "";
                    foreach (var imgbtn in images)
                    {
                        imgbtn.ImageUrl = "~/Pictures/cover1.png";
                    }
                    Session["guess1"] = null;
                    Session["guess2"] = null;
                    guess1 = null;
                    guess2 = null;
                }
            }
        }
        //---------------Function To check for matching Images------------------//
        protected void UpdatePanel2_Load(object sender, EventArgs e)
        {
            int tm = Convert.ToInt16(Session["timer1"]);
            if (tm != 0)
            {
                Label7.Text = Convert.ToString(Convert.ToInt16(Session["timer1"]) - 1);
                Session["timer1"] = Convert.ToString(Convert.ToInt16(Session["timer1"]) - 1);
            }
        }
        protected void Timer5_Tick(object sender, EventArgs e)
        {
            UpdatePanel4.Update();
        }
        protected void UpdatePanel4_Load(object sender, EventArgs e)
        {
            int secs = Convert.ToInt16(Session["timer3"]);
            int count = Convert.ToInt16(Session["counter"]);
            if (secs != 0)
            {
                Label9.Text = Convert.ToString(Convert.ToInt16(Session["timer3"]) - 1);
                Session["timer3"] = Convert.ToString(Convert.ToInt16(Session["timer3"]) - 1);
            }
            else
            {
                if (count != 0)
                {
                    Session["timer3"] = "59";
                    Label2.Text = Convert.ToString(Convert.ToInt16(Session["counter"]) - 1);
                    Session["counter"] = Convert.ToString(Convert.ToInt16(Session["counter"]) - 1);
                }
                else
                {
                    if (secs == 0 && count == 0)
                    {
                        Session["score"] = Label4.Text;
                        Label5.Text = Session["score"].ToString();
                        int finalscore = int.Parse(Label4.Text);
                        Thread storescore = new Thread(() => DBConnectivty.AddScore(finalscore, stdid, gameid));
                        storescore.Start();
                        Response.Redirect("GameOver.aspx");
                        Timer3.Enabled = false;
                    }
                }
            }
        }
        protected void Timer3_Tick(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DBConnectivty.addurl(rand, id);
            DBConnectivty.addurl(rand, idd);
            s1 = "";
            s2 = "";
            foreach (var imgbtn in images)
            {
                imgbtn.ImageUrl = "~/Pictures/cover1.png";
            }
            Session["guess1"] = null;
            Session["guess2"] = null;
            guess1 = null;
            guess2 = null;

            Response.Redirect("StudentHome.aspx");
        }
    }
}