﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Diagnostics;
namespace CourseWorkTwo
{
    public class DBConnectivty
    {
        private static OleDbConnection GetConnection()
        {
            string conn;
            conn = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=C:\Users\ROOCHA THAKKAR\Documents\game.mdb";
            return new OleDbConnection(conn);
        }
        //-------------------------------------------------------------------------------------------------------
        public static List<String> LoadUrl1(int id)
        {
            List<String> url = new List<String>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT * FROM urlchange WHERE id=" + id;
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    url.Add(myReader["url"].ToString());
                }
                return url;
            }
            catch(Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static void addurl(string url,int id)
        {
            OleDbConnection myConnection = GetConnection();
            string myQuery = "UPDATE [urlchange] SET url = " + "'" + url + "'" + " WHERE id  = " + id;

            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------
        public static List<String> Images(int id)
        {
            List<String> img = new List<String>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT * FROM images WHERE gid="+id;
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    img.Add(myReader["url"].ToString());
                }
                return img;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static void AddTeacher(string first,string last,string mail,string pass) 
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO teacher(fname,lname,email,pass) VALUES ('" + first + "','" + last + "','" + mail + "','" + pass + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //-------------------------------------------------------------------------------------------------------
        public static List<Person> LoadTeacher()
        {
            List<Person> person = new List<Person>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT ID, teacher.[fname] & ' ' & [lname] AS name FROM teacher; ";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Person g = new Person(int.Parse(myReader["ID"].ToString()), myReader["name"].ToString());
                    person.Add(g);
                }
                return person;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static void AddStudent(string first, string last, string mail, string pass, string teacher)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO student(fname,lname,email,pass,teacherid) VALUES ('" + first + "','" + last + "','" + mail + "','" + pass + "','" + teacher + "')";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //-------------------------------------------------------------------------------------------------------
        public static List<Person> Login(string email,string pass)
        {
            List<Person> login = new List<Person>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT teacher.email, teacher.pass,teacher.ID FROM teacher WHERE teacher.email= '" + email + "' AND teacher.pass ='" + pass +"'" ;
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Person g = new Person(int.Parse(myReader["ID"].ToString()), myReader["email"].ToString(), myReader["pass"].ToString());
                    login.Add(g);
                }
                return login;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static List<Person> StudentLogin(string email, string pass)
        {
            List<Person> login = new List<Person>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT student.email, student.pass,student.ID FROM student WHERE student.email= '" + email + "' AND student.pass ='" + pass + "'";
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Person g = new Person(int.Parse(myReader["ID"].ToString()), myReader["email"].ToString(), myReader["pass"].ToString());
                    login.Add(g);
                }
                return login;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static List<String> LoadName(int id)
        {
            List<String> url = new List<String>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT * FROM student WHERE ID=" + id;
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    url.Add(myReader["fname"].ToString());
                }
                return url;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static List<String> LoadTName(int id)
        {
            List<String> url = new List<String>();
            OleDbConnection myConnection = GetConnection();

            string selectquery = "SELECT * FROM teacher WHERE ID=" + id;
            OleDbCommand myCommand = new OleDbCommand(selectquery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    url.Add(myReader["fname"].ToString());
                }
                return url;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static void AddScore(int score, int stid, int gameid)
        {
            OleDbConnection myConnection = GetConnection();
            string addquery = "INSERT INTO score(studentid,gameid,score) VALUES (" + stid + "," + gameid + "," + score + ")";
            OleDbCommand myCommand = new OleDbCommand(addquery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
            }
            finally
            {
                myConnection.Close();
            }

        }
        //-------------------------------------------------------------------------------------------------------
        public static List<Student> LoadAllScores(int id)
        {
            List<Student> student = new List<Student>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT [student].[fname] & ' ' & [student].[lname] AS name, gamename, score, studentid FROM student INNER JOIN (game INNER JOIN score ON game.ID = score.gameid) ON student.ID = score.studentid WHERE score.studentid =" + id;
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Student g = new Student(int.Parse(myReader["studentid"].ToString()), myReader["name"].ToString(), int.Parse(myReader["score"].ToString()), myReader["gamename"].ToString());
                    student.Add(g);
                }
                return student;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static List<Student> LoadAll(int id)
        {
            List<Student> student = new List<Student>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT fname ,lname , ID , teacherid, email FROM student WHERE student.teacherid =" + id;
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Student g = new Student(int.Parse(myReader["ID"].ToString()), myReader["fname"].ToString(), int.Parse(myReader["teacherid"].ToString()), myReader["lname"].ToString(), myReader["email"].ToString());
                    student.Add(g);
                }
                return student;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
        //-------------------------------------------------------------------------------------------------------
        public static List<Student> TLoadAllScores(int id)
        {
            List<Student> student = new List<Student>();
            OleDbConnection myConnection = GetConnection();

            string myQuery = "SELECT [student].[fname] & ' ' & [student].[lname] AS name, student.ID, game.gamename, score.score FROM (teacher INNER JOIN student ON teacher.ID = student.teacherid) INNER JOIN (game INNER JOIN score ON game.ID = score.gameid) ON student.ID = score.studentid WHERE student.teacherid=" + id;
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);

            try
            {
                myConnection.Open();
                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Student g = new Student(int.Parse(myReader["ID"].ToString()), myReader["name"].ToString(), int.Parse(myReader["score"].ToString()), myReader["gamename"].ToString());
                    student.Add(g);
                }
                return student;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBHandler", ex);
                return null;
            }
            finally
            {
                myConnection.Close();
            }
        }
    }
}