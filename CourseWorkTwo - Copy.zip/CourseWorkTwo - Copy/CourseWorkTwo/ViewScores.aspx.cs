﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class ViewScores : System.Web.UI.Page
    {
        int stdid;
        DataTable dt = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            stdid = int.Parse(Session["student"].ToString());
            List<Student> student = DBConnectivty.LoadAllScores(stdid);
            foreach(var s in student)
            {
                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                cell1.Text = s.Game;
                TableCell cell2 = new TableCell();
                cell2.Text = s.Score.ToString();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                Table1.Rows.Add(row);
            }

            dt.Columns.Add("Game", typeof(string));
            dt.Columns.Add("Score", typeof(int));

            for(int i = 0; i < student.Count; i++)
            {
                string gamename = student.ElementAt(i).Game;
                int score = student.ElementAt(i).Score;
                dt.Rows.Add(gamename, score);
            }

            BindTheChart(dt);
            
        }

        protected void Chart1_Load(object sender, EventArgs e)
        {

        }
        public void BindTheChart(DataTable dt)
        {
            string[] x = new string[dt.Rows.Count];
            double[] y = new double[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToDouble(dt.Rows[i][1]);
            }
            chart1.Series[0].Points.DataBindXY(x, y);

            chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Column;

            chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -50;
            chart1.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Comic Sans MS", 12, FontStyle.Bold);
            chart1.ChartAreas["ChartArea1"].AxisY.TitleFont = new Font("Comic Sans MS", 12, FontStyle.Bold);
            chart1.ChartAreas["ChartArea1"].AxisX.Minimum = 0;
            chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
            chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
            chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
            chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
            chart1.ChartAreas["ChartArea1"].AxisY.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
            chart1.Series[0].IsValueShownAsLabel = true;
            chart1.ChartAreas["ChartArea1"].AxisY.Title = "Score";
            chart1.ChartAreas["ChartArea1"].AxisX.Title = "Game Played";
            chart1.Width = 500;
        }
    }
}