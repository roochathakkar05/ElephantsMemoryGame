﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CourseWorkTwo
{
    public class Student:Person
    {
        int score;
        int teacherid;
        string game;


        public Student(int i,string f,string l,string e,string p,int score,int teacherid):base(i,f,l,e,p)
        {
            this.score = score;
            this.teacherid = teacherid;
        }
        public Student(int i, string f, int score,string game) : base(i, f)
        {
            this.score = score;
            this.game = game;
        }
        public Student(int i,string f,int teacherid,string e,string l) : base(i, f, e, l)
        {
            this.teacherid = teacherid;
        }
        public int Score
        {
            get
            {
                return score;
            }

            set
            {
                score = value;
            }
        }

        public int Teacherid
        {
            get
            {
                return teacherid;
            }

            set
            {
                teacherid = value;
            }
        }

        public string Game
        {
            get
            {
                return game;
            }

            set
            {
                game = value;
            }
        }
    }
}