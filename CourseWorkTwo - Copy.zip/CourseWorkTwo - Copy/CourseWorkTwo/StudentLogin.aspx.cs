﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class StudentLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Register_Click(object sender, EventArgs e)
        {
            string password = Password.Text;
            string email = Email.Text;
            if (email == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your email";
            }
            else if (password == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please enter your password";
            }
            else
            {
                string checkemail = "";
                string checkpass = "";
                int checkid = 0;
                List<Person> person = DBConnectivty.StudentLogin(email, password);
                foreach (var p in person)
                {
                    checkemail = p.Email;
                    checkpass = p.Pass;
                    checkid = p.Id;
                }
                if (checkemail == email)
                {
                    if (checkpass == password)
                    {
                        Label1.Visible = true;
                        Label1.ForeColor = Color.FromArgb(51, 204, 51);
                        Label1.Text = "Login is successful";
                        Email.Text = "";
                        Session["student"] = checkid.ToString();
                        Label1.Text = Session["student"].ToString();
                        Response.Redirect("RulesandRegulation.aspx");
                    }
                    else
                    {
                        Label1.Visible = true;
                        Label1.Text = "The email and or password is incorrect";
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "The email and or password is incorrect";
                }

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}