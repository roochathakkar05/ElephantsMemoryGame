﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseWorkTwo
{
    public partial class TeacherHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<String> name = DBConnectivty.LoadTName(int.Parse(Session["teacher"].ToString()));
            foreach (var n in name)
            {
                Label1.Text = n;
            }
        }

        protected void Students_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewStudents.aspx");
        }

        protected void view_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewStudentsScores.aspx");
        }

        protected void view0_Click(object sender, EventArgs e)
        {
            Session["teacher"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}